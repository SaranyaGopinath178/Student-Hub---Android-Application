package com.example.saranya.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainPage extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semester);

        Button next = (Button) findViewById(R.id.Button01);

        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Course.class);
                startActivityForResult(myIntent, 0);
            }
        });
        Button next1 = (Button) findViewById(R.id.Button03);
        next1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Course.class);
                startActivityForResult(myIntent, 0);
            }
        });
        Button next2 = (Button) findViewById(R.id.Button04);
        next2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Course.class);
                startActivityForResult(myIntent, 0);
            }
        });
        Button next3 = (Button) findViewById(R.id.Button05);
        next3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Event.class);
                startActivityForResult(myIntent, 0);
            }
        });
        Button next4 = (Button) findViewById(R.id.Button06);
        next4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), To_Do.class);
                startActivityForResult(myIntent, 0);
            }
        });
    }
}
