package com.example.saranya.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

public class Course extends Activity {
    ArrayList<String> selection = new ArrayList<String>();
    TextView final_text;



    /**
     * Called when the activity is first created.
     */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);
        final_text = (TextView)findViewById(R.id.final_result);
        final_text.setEnabled(false);

        Button next = (Button) findViewById(R.id.Button02);
        next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent();
                setResult(RESULT_OK, intent);
                finish();
            }

        });


    }
    public void selectItem(View view)
    {
        boolean checked = ((CheckBox) view).isChecked();
        switch (view.getId())
        {
            case R.id.CoreCourse1:
                if(checked) {
                    selection.add("Algorithm Design, Analysis and Implementation");
                }
                else
                {
                    selection.remove("Algorithm Design, Analysis and Implementation");

                }
                break;
            case R.id.CoreCourse2:
                if(checked) {
                    selection.add("Computer Organization");
                }
                else
                {
                    selection.remove("Computer Organization");

                }
                break;
            case R.id.CoreCourse3:
                if(checked) {
                    selection.add("Programming Languages");
                }
                else
                {
                    selection.remove("Programming Languages");
                }
                break;
            case R.id.CoreCourse4:
                if(checked) {
                    selection.add("OperatingSystems");
                }
                else
                {
                    selection.remove("OperatingSystems");

                }
                break;
            case R.id.ElecCourse1:
                if(checked) {
                    selection.add("Networking and Security");
                }
                else
                {
                    selection.remove("Networking and Security");

                }
                break;
            case R.id.ElecCourse2:
                if(checked) {
                    selection.add("Databases and Intelligent Systems");
                }
                else
                {
                    selection.remove("Databases and Intelligent Systems");

                }
                break;
            case R.id.ElecCourse3:
                if(checked) {
                    selection.add("Visualization and Graphics");
                }
                else
                {
                    selection.remove("Visualization and Graphics");

                }
                break;
            case R.id.ElecCourse4:
                if(checked) {
                    selection.add("Software Engineering");
                }
                else
                {
                    selection.remove("Software Engineering");

                }
                break;
            case R.id.ElecCourse5:
                if(checked) {
                    selection.add("Theory");
                }
                else
                {
                    selection.remove("Theory");

                }
                break;
            case R.id.ElecCourse6:
                if(checked) {
                    selection.add("Systems");
                }
                else
                {
                    selection.remove("Systems");

                }
                break;
        }
    }
    public void finalSelection(View view)
    {
        String final_course_selection = "";
        for(String Selections: selection){
            final_course_selection = final_course_selection + Selections + "\n";
        }
        final_text.setText(final_course_selection);
        final_text.setEnabled(true);
    }

}