package com.example.saranya.studenthub;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//import android.view.Menu;

public class Login extends Activity {
    DatabaseHelper helper = new DatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    //public boolean onCreateOptionsMenu (Menu menu){
    //  getMenuInflater().inflate(R.menu.menu_main, menu);
    //return true;
//}
    public void onButtonClick (View v){
        if (v.getId()==R.id.blogin)
        {
            EditText a = (EditText)findViewById(R.id.Tfusername);
            String str = a.getText().toString();
            EditText b = (EditText)findViewById(R.id.Tfpass);
            String pass = b.getText().toString();
            Log.d(pass,"Password1");

            String password = helper.searchPass(str);
            Log.d(password,"Password2");

            if (pass.equals(password)){

                Intent i = new Intent(Login.this, MainPage.class);
                i.putExtra("Username", str);
                startActivity(i);
            }
            else {
                Toast temp = Toast.makeText(Login.this,"Username and Password don't match!",Toast.LENGTH_SHORT);
                temp.show();
            }

        }

        if (v.getId() == R.id.bsignup)
        {
            Intent i = new Intent(Login.this, SignUp.class);
            startActivity(i);
        }
    }
}
